import numpy as np
import matplotlib.pyplot as plt

T = 3
omega0 = 2 * np.pi / T
n_max = 20  

def fourier_coefficients(n_max):
    n_values = np.arange(-n_max, n_max + 1)
    c_n = np.zeros_like(n_values, dtype=complex)
    
    for i, n in enumerate(n_values):
        if n == 0:
            c0 = (2 * 1 + 1 * 1 + 0 * 1) / T
            c_n[i] = c0
        else:
            term1 = 2 * (np.exp(-1j * n * omega0 * 1) - np.exp(-1j * n * omega0 * 0)) / (-1j * n * omega0)
            term2 = 1 * (np.exp(-1j * n * omega0 * 2) - np.exp(-1j * n * omega0 * 1)) / (-1j * n * omega0)
            c_n[i] = (term1 + term2) / T
    
    return n_values, c_n

n_values, c_n = fourier_coefficients(n_max)

plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.stem(n_values, np.abs(c_n))
plt.title('abs $|c_n|$')
plt.xlabel('n')
plt.ylabel('$|c_n|$')
plt.grid()

plt.subplot(1, 2, 2)
plt.stem(n_values, np.angle(c_n))
plt.title('phase $\phi_n$')
plt.xlabel('n')
plt.ylabel('$\phi_n$ (radian)')
plt.grid()

plt.tight_layout()
plt.show()