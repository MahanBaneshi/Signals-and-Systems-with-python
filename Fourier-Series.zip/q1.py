import numpy as np
import matplotlib.pyplot as plt

def compute_fourier_coefficients(x_func, t_min, t_max, N):
    T0 = t_max - t_min
    omega0 = 2 * np.pi / T0
    t_vals = np.linspace(t_min, t_max, 1000)

    k_vals = np.arange(-N, N+1)
    a_k = np.zeros(len(k_vals), dtype=complex)

    for idx, k in enumerate(k_vals):
        integrand = x_func(t_vals) * np.exp(-1j * k * omega0 * t_vals)
        a_k[idx] = (1 / T0) * np.trapz(integrand, t_vals)

    return k_vals, a_k

def reconstruct_signal_from_fourier(k_vals, a_k, t_vals):
    reconstructed_signal = np.zeros_like(t_vals, dtype=complex)
    
    for k, coeff in zip(k_vals, a_k):
        reconstructed_signal += coeff * np.exp(1j * k * (2 * np.pi / (t_vals[-1] - t_vals[0])) * t_vals)
    
    return reconstructed_signal.real

t_min = 0
t_max = 2 * np.pi
t_vals = np.linspace(t_min, t_max, 1000)

def square_wave(t):
    t = np.mod(t, 2 * np.pi)
    return np.where(t < np.pi, 1, -1)

functions = [
    {"func": lambda t: np.sin(t), "name": "sin(t)"},
    {"func": lambda t: np.cos(2 * t), "name": "cos(2t)"},
    
    {"func": lambda t: t, "name": "linear t"},
    {"func": square_wave, "name": "pulse"}
]

for f in functions:
    k_vals, a_k = compute_fourier_coefficients(f["func"], t_min, t_max, 20)
    reconstructed_signal = reconstruct_signal_from_fourier(k_vals, a_k, t_vals)
    fig, axes = plt.subplots(2, 1, figsize=(10, 12))

    axes[0].plot(t_vals, f["func"](t_vals), label=f"Original: {f['name']}", linestyle="--")
    axes[0].plot(t_vals, reconstructed_signal, label=f"Reconstructed: {f['name']}")
    axes[0].set_title(f"Original vs Reconstructed Signal for {f['name']}")
    axes[0].set_xlabel("t")
    axes[0].set_ylabel("Signal Value")
    axes[0].legend()
    axes[0].grid(True)

    axes[1].stem(k_vals, np.abs(a_k), basefmt=" ")
    axes[1].set_title(f"Fourier Coefficients for {f['name']}")
    axes[1].set_xlabel("k")
    axes[1].set_ylabel("|a_k| (Magnitude)")
    axes[1].grid(True)

    plt.tight_layout()
    plt.show()