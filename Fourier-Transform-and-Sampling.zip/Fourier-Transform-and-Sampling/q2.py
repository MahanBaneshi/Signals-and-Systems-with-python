import numpy as np
import matplotlib.pyplot as plt

# Signal parameters
fs = 1000  # Sampling rate in Hz
t = np.linspace(0, 1, fs, endpoint=False)  # Time vector

# Clean signal: combination of 5 Hz and 15 Hz
signal_clean = np.sin(2 * np.pi * 5 * t) + 0.5 * np.sin(2 * np.pi * 15 * t)

# Add uniform noise
noise = np.random.uniform(-0.5, 0.5, size=fs)
signal_noisy = signal_clean + noise

# FFT of noisy signal
fft_result = np.fft.fft(signal_noisy)
fft_freqs = np.fft.fftfreq(len(fft_result), 1/fs)
fft_magnitude = np.abs(fft_result)

# Low-pass filter: keep frequencies <= 30 Hz
cutoff_freq = 50
low_pass_mask = np.abs(fft_freqs) <= cutoff_freq
filtered_fft = fft_result * low_pass_mask
filtered_fft_magnitude = np.abs(filtered_fft)

# Inverse FFT to get filtered signal
reconstructed_signal = np.fft.ifft(filtered_fft).real

# Plotting
plt.figure(figsize=(14, 10))

# 1. Time-domain signals
plt.subplot(4, 1, 1)
plt.plot(t, signal_noisy, label='Noisy Signal')
plt.plot(t, signal_clean, linestyle='--', label='Clean Signal')
plt.title("Original and Clean Signal (Time Domain)")
plt.xlabel("Time (s)")
plt.ylabel("Amplitude")
plt.legend()
plt.grid()

# 2. FFT of original signal
plt.subplot(4, 1, 2)
plt.plot(fft_freqs[:fs//2], fft_magnitude[:fs//2], label='Original FFT')
plt.title("FFT of Noisy Signal (Frequency Domain)")
plt.xlabel("Frequency (Hz)")
plt.ylabel("Magnitude")
plt.legend()
plt.grid()

# 3. Filtered FFT
plt.subplot(4, 1, 3)
plt.plot(fft_freqs[:fs//2], filtered_fft_magnitude[:fs//2], color='orange', label='Filtered FFT')
plt.title("Filtered FFT (Low-pass, cutoff = 30 Hz)")
plt.xlabel("Frequency (Hz)")
plt.ylabel("Magnitude")
plt.legend()
plt.grid()

# 4. Reconstructed signal
plt.subplot(4, 1, 4)
plt.plot(t, reconstructed_signal, label='Reconstructed Signal (from Filtered FFT)')
plt.plot(t, signal_clean, linestyle='--', label='Clean Signal')
plt.title("Reconstructed Signal (Time Domain)")
plt.xlabel("Time (s)")
plt.ylabel("Amplitude")
plt.legend()
plt.grid()

plt.tight_layout()
plt.show()
