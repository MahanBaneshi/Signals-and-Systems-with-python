import numpy as np
import matplotlib.pyplot as plt

x = np.array([1, 2, 3, 4])
N = len(x)
k0 = 2

n = np.arange(N)
modulation = np.exp(1j * 2 * np.pi * k0 * n / N)

x_mod = x * modulation

X = np.fft.fft(x)
X_mod = np.fft.fft(x_mod)

plt.figure(figsize=(12, 4))

plt.subplot(1, 2, 1)
plt.stem(np.abs(X))
plt.title("Magnitude of DFT (Original Signal)")
plt.xlabel("k")
plt.ylabel("|X[k]|")

plt.subplot(1, 2, 2)
plt.stem(np.abs(X_mod))
plt.title("Magnitude of DFT (Modulated Signal)")
plt.xlabel("k")
plt.ylabel("|X_mod[k]|")

plt.tight_layout()
plt.show()
