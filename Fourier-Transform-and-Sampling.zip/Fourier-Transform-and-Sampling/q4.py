import numpy as np
import matplotlib.pyplot as plt

# سیگنال پیوسته اصلی
f0 = 1  # فرکانس سیگنال (Hz)
t_cont = np.linspace(-1, 1, 1000)  # محور زمان از -π تا π
x_cont = np.sin(2 * np.pi * f0 * t_cont)

# نرخ‌های نمونه‌برداری جدید
sampling_rates = [50, 30, 20]

for fs in sampling_rates:
    Ts = 1 / fs
    t_sampled = np.arange(-1, 1, Ts)
    x_sampled = np.sin(2 * np.pi * f0 * t_sampled)

    # رسم نمودار
    plt.figure(figsize=(10, 6))
    plt.plot(t_cont, x_cont, 'b-', label='Continuous signal', linewidth=2)
    plt.stem(t_sampled, x_sampled, linefmt='r-', markerfmt='ro', basefmt='k-', label='Sampled points')
    plt.title(f"Sampling rate: {fs} Hz", fontsize=16)
    plt.xlabel("Time (s)", fontsize=14)
    plt.ylabel("Amplitude", fontsize=14)
    plt.grid(True)
    plt.legend(fontsize=12)
    plt.tight_layout()
    plt.show()
