import numpy as np
import matplotlib.pyplot as plt

# Continuous Fourier Transform method
def continuous_fourier_transform(signal, t, freqs):
    dt = t[1] - t[0]
    X = np.zeros(len(freqs), dtype=complex)
    for i, f in enumerate(freqs):
        X[i] = np.sum(signal * np.exp(-2j * np.pi * f * t)) * dt
    return X

# Inverse Continuous Fourier Transform method
def inverse_continuous_fourier_transform(X, freqs, t):
    df = freqs[1] - freqs[0]
    signal = np.zeros(len(t), dtype=complex)
    for i, time in enumerate(t):
        signal[i] = np.sum(X * np.exp(2j * np.pi * freqs * time)) * df
    return signal

# Frequency axis: -50 to +50 Hz
freqs = np.linspace(-50, 50, 2000)

# --- a) Step signal ---
t1 = np.linspace(0, 1, 1000, endpoint=False)
x1 = np.heaviside(t1 - 0.5, 1.0)
X1 = continuous_fourier_transform(x1, t1, freqs)
x1_rec = inverse_continuous_fourier_transform(X1, freqs, t1)

# --- b) Pulse signal: 1 from t=0.25 to 0.75 ---
t2 = np.linspace(0, 1, 1000, endpoint=False)
x2 = np.where((t2 >= 0.25) & (t2 < 0.75), 1.0, 0.0)
X2 = continuous_fourier_transform(x2, t2, freqs)
x2_rec = inverse_continuous_fourier_transform(X2, freqs, t2)

# --- c) Sinusoidal signal: 10 Hz sine ---
t3 = np.linspace(0, 1, 1000, endpoint=False)
x3 = np.sin(2 * np.pi * 2.5 * t3)
X3 = continuous_fourier_transform(x3, t3, freqs)
x3_rec = inverse_continuous_fourier_transform(X3, freqs, t3)

# --- d) Multiple sinusoids (no noise) ---
t4 = np.linspace(0, 1, 1000, endpoint=False)
x4 = np.sin(2 * np.pi * 15 * t4) 
X4 = continuous_fourier_transform(x4, t4, freqs)
x4_rec = inverse_continuous_fourier_transform(X4, freqs, t4)

# === PLOT 1: Step and Pulse ===
fig1, axs1 = plt.subplots(2, 3, figsize=(16, 8))
axs1[0, 0].plot(t1, x1)
axs1[0, 0].set_title("Step signal")

axs1[0, 1].plot(freqs, np.abs(X1))
axs1[0, 1].set_title("FT of step")

axs1[0, 2].plot(t1, x1_rec.real)
axs1[0, 2].set_title("Reconstructed step")

axs1[1, 0].plot(t2, x2)
axs1[1, 0].set_title("Pulse signal ")

axs1[1, 1].plot(freqs, np.abs(X2))
axs1[1, 1].set_title("FT of pulse")

axs1[1, 2].plot(t2, x2_rec.real)
axs1[1, 2].set_title("Reconstructed pulse")

for ax in axs1.flat:
    ax.set_xlabel("Time [s]" if "signal" in ax.get_title() or "Reconstructed" in ax.get_title() else "Frequency [Hz]")
    ax.set_ylabel("Amplitude")

fig1.tight_layout()
plt.show()

# === PLOT 2: Sinusoids ===
fig2, axs2 = plt.subplots(2, 3, figsize=(16, 8))
axs2[0, 0].plot(t3, x3)
axs2[0, 0].set_title("Pure sinusoid (5 Hz)")

axs2[0, 1].plot(freqs, np.abs(X3))
axs2[0, 1].set_title("FT of 5Hz sinusoid")

axs2[0, 2].plot(t3, x3_rec.real)
axs2[0, 2].set_title("Reconstructed 5Hz sinusoid")

axs2[1, 0].plot(t4, x4)
axs2[1, 0].set_title("Pure sinusoid (30 Hz)")

axs2[1, 1].plot(freqs, np.abs(X4))
axs2[1, 1].set_title("FT of 5Hz sinusoid")

axs2[1, 2].plot(t4, x4_rec.real)
axs2[1, 2].set_title("Reconstructed 5Hz sinusoid")

for ax in axs2.flat:
    ax.set_xlabel("Time [s]" if "signal" in ax.get_title() or "Reconstructed" in ax.get_title() else "Frequency [Hz]")
    ax.set_ylabel("Amplitude")

fig2.tight_layout()
plt.show()
